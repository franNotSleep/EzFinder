export const ASYNC_STORAGE = Symbol('async_storage');
